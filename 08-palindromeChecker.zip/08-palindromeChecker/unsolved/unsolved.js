// Write a function that determines whether a given string is a palindrome or not.
// Before you start, make sure you understand what a palindrome is, and create a few test 
// palindromes to make sure your code works! If you finish early, think about other 
// potential solutions, and/or how to handle strings with spaces or mixes of capital/lower 
// case letters.