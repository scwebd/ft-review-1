var animals = ["gerbil", "mermaid", "hyena", "unicorn", "cyclops", "bald eagle", "puma"];

// ?????
console.log(animals.length);

// ?????
console.log(animals[2]);

// ?????
console.log(animals[5]);

// ?????
console.log(animals[0]);

// ?????
console.log(animals[animals.length]);

// ?????
console.log(animals[animals.length - 1]);

// ?????
console.log(animals.indexOf("bear"));

// ?????
console.log(animals.indexOf("gerbil"));


// ---------------------------------------------------------------
// Now, let's modify our array a little bit
// ---------------------------------------------------------------

// Add at least two new animals to the end of the existing array

// Then log out the entire array

// Log the last item in the array, *without* specifying the index

// Log out the array again -- note the changes

// Return the first item in the array, *without* specifying the index

// Log out the array again... what's changed?

// Add one or more members to the beginning of the array

// And now print out the whole zoo full of animals one more time!