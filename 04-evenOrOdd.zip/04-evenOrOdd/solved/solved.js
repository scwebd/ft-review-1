function evenOrOdd(number) {
  return (number % 2 === 0) ? "Even" : "Odd";
}

// Should log "Even"
console.log(evenOrOdd(2));
// Should log "Odd"
console.log(evenOrOdd(17));