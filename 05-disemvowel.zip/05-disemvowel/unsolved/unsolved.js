// Write a function that takes in a string and removes ALL vowels (a, e, i, o, u).
// HINT: Try using a JavaScript regex!