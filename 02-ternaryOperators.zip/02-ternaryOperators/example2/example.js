var numPets = 1;

console.log("You have " + numPets + (numPets === 1 ? " pet." : " pets."));